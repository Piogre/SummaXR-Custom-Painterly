IMPORTANT!!!
============

Unlike other contents of this pack the license for the contents of this customnoredist folder were purchased by the SummaXR server owner.
The contents are licensed for modification and use, but not redistribution.
Technically none of the pack is available to redistribute, but this in particular is hands-off.
They can be used as part of this pack, but extracting them and reusing them may be a violation of the DMCA.
I say "may" because I'm not a lawyer so I'm not sure.
But just to be sure leave these be.
Or don't, I'm not a cop.